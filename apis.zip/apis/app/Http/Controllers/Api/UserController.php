<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Upload;
use App\User;
use Countable;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::get();
        if (count($users) > 0) {
            $response = [
                'message' => Count($users) . ' users found',
                'status' => 1,
                'data' => $users,
            ];
            return response()->json($response);
        } else {
            $response = [
                'message' => Count($users) . ' user found',
                'status' => 0,
            ];
            return response()->json($response);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $users = new User;
        $users->name = $request['name'];
        $users->email = $request['email'];
        $users->password = $request['password'];
        $users->contact = $request['contact'];
        $users->pincode = $request['pincode'];
        $users->address = $request['address'];
        $users->save();
        return response()->json($users);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $users = User::find($id);
        // $users=User::where('id','=',$id)->get();

        if (is_null($users)) {
            $response = [
                'message' => 'user not found',
                'status' => 0,
                'data' => $users,
            ];
        } else {
            $response = [
                'message' => 'user found successfully',
                'status' => 1,
                'data' => $users,
            ];
        }
        return response()->json($response);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $users = User::find($id);
        if (is_null($users)) {
            $response = [
                'message' => 'User not Found',
                'status' => 0,
            ];
        } else {
            $users->name = $request['name'];
            $users->email = $request['email'];
            $users->password = $request['password'];
            $users->contact = $request['contact'];
            $users->pincode = $request['pincode'];
            $users->address = $request['address'];
            $users->save();

            $response = [
                'message' => 'User updated successfully',
                'status' => 1,
            ];
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $users = User::find($id);
        if (is_null($users)) {
            $response = [
                'message' => 'user not found',
                'status' => 0,
            ];
        } else {
            $users->delete();
            $response = [
                'message' => 'user deleted successfully',
                'status' => 1,
            ];
        }
        return response()->json($response);
    }

    //using patch method
    public function changepassword($id, Request $request)
    {
        $users = User::find($id);
        if (is_null($users)) {
            $response = [
                'message' => 'user not found',
                'status' => 0,
            ];
        } else {
            if ($users->password == $request['old_password']) {
                if ($request['new_password'] == $request['confirm_password']) {
                    $users->password = $request['new_password'];
                    $users->save();
                    $response = [
                        'message' => 'password changed successfully',
                        'status' => 1,
                    ];
                } else {
                    $response = [
                        'message' => 'new password and confirm password are not same',
                        'status' => 0,
                    ];
                }
            } else {
                $response = [
                    'message' => 'old password not matching',
                    'status' => 0,
                ];
            }
        }

        return response()->json($response);
    }




    public function upload(Request $request)
    {

        if ($request->file('file') == null) {

            $response = [
                'message' => 'file not uploaded',
                'status' => 0,
            ];
        } else {
           $file_name= $request->file('file')->getClientOriginalName();
            $request->file('file')->move('..\uploaded_files', $file_name);

            $uploadfile = new Upload;
            $uploadfile->filename = $request->file('file')->getClientOriginalName();
            $uploadfile->save();
            $response = [
                'message' =>  'file uploaded successfully',
                'status' => 1,
            ];
        }

        return response()->json($response);
    }

    public function display_uploaded($id){
        $display=Upload::find($id);
        if(is_null($display)){
            $response = [
                'message' =>  'data not found',
                'status' => 0,
            ];
        }
        else{
            $data=$display->filename;
            $response = [
                'message' =>  'data found successfully',
                'status' => 1,
                'data'=> $data
            ];
        }
        return response()->json($response);
    }
}
