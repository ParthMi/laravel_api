<?php

use App\Http\Controllers\Api\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });


Route::get('/test',function(){
    p("working");
});
Route::post('/user/store','Api\UserController@store');
Route::get('/user/get','Api\UserController@index');

Route::get('/user/{id}','Api\UserController@show');
Route::delete('/user/delete/{id}','Api\UserController@destroy');

//put method is use for update one raw or all column
Route::put('/user/update/{id}','Api\UserController@update'); 


Route::patch('/user/changepassword/{id}','Api\UserController@changepassword'); 

Route::post('/user/upload','Api\UserController@upload');

Route::get('/user/display-uploaded/{id}','Api\UserController@display_uploaded');